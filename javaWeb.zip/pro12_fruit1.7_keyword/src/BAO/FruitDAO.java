package BAO;


import project.Fruit;

import java.sql.Connection;
import java.util.List;

public interface FruitDAO {
    List<Fruit> getFruitList(String keyword ,int pagenumber);

    //根据fid获取特定的水果库存信息
    Fruit getFruitByFid (Connection connection, int fid);

    void upDateFruit(Connection connection,Fruit fruit);

    void delFruit(int fid);

    void addFruit(Fruit fruit);

    int countFruit(String keyword);
}
