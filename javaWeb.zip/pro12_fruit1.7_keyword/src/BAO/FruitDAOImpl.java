package BAO;

import project.DBUtils;
import project.Fruit;

import java.sql.Connection;
import java.util.List;

public class FruitDAOImpl extends BaseDAO implements FruitDAO {

    @Override
    public List<Fruit> getFruitList(String keyword,int pagenumber) {
        String sql = "select * from fruit where fname like ? or remark like ? limit ? , 5";
        Connection connection = DBUtils.getConnection();
        List<Fruit> fruitList= getForList(connection,Fruit.class,sql,"%"+keyword+"%","%"+keyword+"%",(pagenumber-1)*5);
        return fruitList;
    }



    @Override
    public Fruit getFruitByFid(Connection connection,int fid) {
        String sql = "select * from fruit where fid = ?";
        Fruit fruit = getInstance(connection,Fruit.class,sql,fid);
        return fruit;
    }


    @Override
    public void upDateFruit(Connection connection,Fruit fruit) {
        String sql = "update fruit set fname = ? , fprice = ? ,fcount =? where fid = ?";
        update(connection,sql,fruit.getFname(),fruit.getFprice(),fruit.getFcount(),fruit.getFid());
    }

    @Override
    public void delFruit(int fid) {
        String sql = "delete from fruit where fid = ?";
        Connection connection = DBUtils.getConnection();
        update(connection,sql,fid);
    }

    @Override
    public void addFruit(Fruit fruit) {
        String sql = "insert into fruit(fname,fprice,fcount)value(?,?,?)";
        Connection connection =DBUtils.getConnection();
        update(connection,sql,fruit.getFname(),fruit.getFprice(),fruit.getFcount());
    }

    public int countFruit(String keyword){
        String sql = "select count(*) from fruit where fname like ? or remark like ?";
        Connection connection = DBUtils.getConnection();
        return ((Long)getValue(connection,sql,"%"+keyword+"%","%"+keyword+"%")).intValue();

    }
}
