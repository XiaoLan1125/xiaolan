package servlets;


import BAO.FruitDAOImpl;
import myspringmvc.ViewBaseServlet;
import project.Fruit;
import util.StringUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/index")
public class IndexServlet extends ViewBaseServlet {

    FruitDAOImpl fruitDAO =new FruitDAOImpl();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String oper = request.getParameter("oper");
        //如果oper!=null, 说明是通过表单的查询按钮得到的
        //如果oper = null, 说明没有点查询，列表是默认显示，否则列表是查询所得到的列表
        HttpSession session = request.getSession();
        int pagenumber=1;
        String keyword = null;
        if(StringUtil.isNotEmpty(oper) && "search".equals(oper)){
            //说明是点击表单查询发送过来的请求
            //此时，pageno应该还原为1，keyword 应该从请求参数种获取
            pagenumber = 1;
            keyword = request.getParameter("keyword");
            if(StringUtil.isEmpty(keyword)){
                keyword = "";
            }
            session.setAttribute("keyword",keyword);

        }else{
            //说明此处不是点击表单的查询按钮得到的keyword
            String pageNoStr = request.getParameter("pagenumber");
            if(StringUtil.isNotEmpty(pageNoStr)){
                pagenumber=Integer.parseInt(pageNoStr);
            }
            Object keywordObj = session.getAttribute("keyword");
            if(keywordObj!=null){
                keyword = (String) keywordObj;
            }else{
                keyword="";
            }
        }






        session.setAttribute("pageno",pagenumber);

        int  countfruit = fruitDAO.countFruit(keyword);
        int  countpage = (countfruit+5-1)/5;
        session.setAttribute("countpage",countpage);

        List<Fruit> fruitList = fruitDAO.getFruitList(keyword,pagenumber);
        session.setAttribute("fruitList",fruitList);
        //此处的视图名称 index
        //thymleaf会将这个逻辑视图名称对应到物理视图名称上
        super.processTemplate("index",request,response);
    }
}
