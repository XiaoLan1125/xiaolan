package BAO;




import project.DBUtils;

import java.lang.reflect.Field;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * &#064;program:  DAO
 * &#064;description:   DAO父类，基础类
 * &#064;author:  作者:Xiao lan
 * &#064;create:  2022-07-23 16:43
 **/
public abstract class BaseDAO {
    /**
     * &#064;Description:  //通用的增删改方法
     * &#064;return:  int
     * &#064;Author:  Xian Lan
     * &#064;Date:  2022/7/23
     */

    public int update(Connection connection,String sql,Object...args){
        PreparedStatement preparedStatement =null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            for(int i = 0;i<args.length;i++){
                preparedStatement.setObject(i+1,args[i]);
            }
            return preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            DBUtils.closeAll(null,preparedStatement,null);
        }
    }

    /**
     * &#064;Description:  通用的查询单个方法
    * &#064;return:  class类<T>
     * * @Author: Xian Lan
     * &#064;Date:  2022/7/23
     */
    public <T> T getInstance(Connection connection, Class<T> clazz, String sql, Object...args){
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            for(int i = 0;i<args.length;i++){
                preparedStatement.setObject(i+1,args[i]);
            }
            resultSet = preparedStatement.executeQuery();
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            int columnCount = resultSetMetaData.getColumnCount();
            if(resultSet.next()){
                T t = clazz.getDeclaredConstructor().newInstance();

                for(int i = 0;i < columnCount;i++){
                    Object columnvalue = resultSet.getObject(i + 1);
                    String columnname = resultSetMetaData.getColumnLabel(i+1);
                    Field field = clazz.getDeclaredField(columnname);
                    field.setAccessible(true);
                    field.set(t,columnvalue);
                }
                return t;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            DBUtils.closeAll(null,preparedStatement,resultSet);
        }
        return null;
    }

    /**
     * &#064;Description:  通用查询多条数据的方法
    * &#064;return:  List<T>
    * &#064;Author:  Xian Lan
     * &#064;Date:  2022/7/23
     */

    public <T> List<T> getForList(Connection connection, Class<T> clazz, String sql, Object...args){
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            for(int i =0;i<args.length;i++){
                preparedStatement.setObject(i+1,args[i]);
            }
            resultSet = preparedStatement.executeQuery();
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            int columnCount = resultSetMetaData.getColumnCount();
            List<T> list = new ArrayList<>();
            while(resultSet.next()){
                T e= clazz.newInstance();
                for(int i = 0;i<columnCount;i++){
                   Object columnvalue = resultSet.getObject(i+1);
                   String columnname = resultSetMetaData.getColumnLabel(i+1);
                   Field field = clazz.getDeclaredField(columnname);
                   field.setAccessible(true);
                   field.set(e,columnvalue);

                }
                list.add(e);
            }
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            DBUtils.closeAll(null,preparedStatement,resultSet);
        }
    }

    /**
     * &#064;Description:  查询特殊值的方法
     * &#064;return:  泛型方法和泛型类型的数据<E>
     * &#064;Author:  Xian Lan
     * &#064;Date:  2022/7/23
     */
    public <E> E getValue(Connection connection,String sql,Object...args){
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            for(int i = 0; i<args.length; i++){
                preparedStatement.setObject(i+1,args[i]);
            }
            resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                return (E)resultSet.getObject(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            DBUtils.closeAll(null,preparedStatement,resultSet);
        }
        return null;
    }
}
