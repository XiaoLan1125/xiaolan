package BAO;


import project.Fruit;

import java.sql.Connection;
import java.util.List;

public class FruitDAOImpl extends BaseDAO implements FruitDAO {

    @Override
    public List<Fruit> getFruitList(Connection connection) {
        String sql = "select * from fruit";
        List<Fruit> fruitList= getForList(connection,Fruit.class,sql);
        return fruitList;
    }
}
