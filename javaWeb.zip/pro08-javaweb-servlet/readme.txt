1.设置编码:
2.Servlet的继承关系：
    1.继承关系
    javax.servlet.Servlet接口
        javax.servlet.GenericServlet抽象类。
            javax.servlet.http.HttpServlet抽象子类
    2.相关方法：
        javax.servlet.Servlet接口：
            void init(config)--初始化方法
            void service(request,response) -- 服务方法
            void destory() - 销毁方法。

            javax.servlet.GenericServlet抽象类：
                void service(request,rsponse)--仍是抽象的方法

            javax.servlet.http.HttpServlet  抽象子类：
                void servlet(request,rsponse){}  --不是抽象方法
                1.String method = req.getMethod();获取请求的方式
                2.各种if判断，根据不同的请求方式，决定调用的不同的do方法
                3.在HttpServlet这个抽象类中，do方法都差不多，基本一样。
                protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                        String method = req.getMethod();
                        long lastModified;
                        if(method.equals("POST")) {
                            this.doPost(req, resp);
                        }else if (method.equals("HEAD")) {
                            lastModified = this.getLastModified(req);
                            this.maybeSetLastModified(resp, lastModified);
                            this.doHead(req, resp);
                        } else if。。。(七大请求方式)

                protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                        String msg = lStrings.getString("http.method_post_not_supported");
                        this.sendMethodNotAllowed(req, resp, msg);
                    }

                private void sendMethodNotAllowed(HttpServletRequest req, HttpServletResponse resp, String msg) throws IOException {
                        String protocol = req.getProtocol();
                        if (protocol.length() != 0 && !protocol.endsWith("0.9") && !protocol.endsWith("1.0")) {
                            resp.sendError(405, msg);
                        } else {
                            resp.sendError(400, msg);
                        }
                    }
    3.小结：
    (1) 继承关系：HttpServlet -> GenericServlet ->Servlet
    (2) Servlet中的核心方法：init(), service(),destroy()
    (3) 服务方法：当有请求过来是=时，service方法会自动响应（其实是tomcat容器调用的）
                在HttpServlet中我们会去分析请求的方式：get，post，head，delete等等。
                那么在HttpServlet中这些方法默认都是405的实现风格，子类实现对应的方法，否则报错405
    (4) 因此我们在创建servlet时，我们才会去考虑请求的方法，从而决定重写相应的do方法。


3.Servlet的生命周期
    1) 生命周期：从创建到结束。对应servlet中的三个方法:
        void init(config)--初始化方法
        void service(request,response) -- 服务方法
        void destory() - 销毁方法。
    2)默认情况下：
        第一次接收请求的时候，这个Servlet会进行实例化，初始化，然后服务
        从第二次请求开始，每一次都是服务，
        当容器关闭时，其中的所有的servlet实例会被销毁，调用销毁方法。
    3)  通过案例我们发现：
        servlet实例tomacat只会创建一个，所有的请求都是这个实例去响应的。
        默认情况，第一次请求时tomcat才会实例化，然后去服务。好处：提高系统的启动速度。缺点：第一次请求时耗时较长。
        结论：如果需要提高系统的响应速度，我们应该设置servlet的初始化时机。
    4)  Servlet的初始化时机：
        默认是第一次接收请求时，实例化，初始化
        我们可以通过<load-on-strartup>来设置servlet启动的先后顺序，数字越小优先级越高。
        <load-on-startup>1</load-on-startup>
    5)  Servlet在容器中是：单例的，线程不安全的
        -单例：所有的请求都是同一个实例去响应
        -线程不安全：一个线程需要根据这个实例中的某一个成员变量值去做逻辑判断。但是在中间某个时机，另一个线程改变改变了这个成员变量的值，从而导致第一个线程的执行路径发生了变化。
        -线程不安全的启发：尽量不要在servlet中定义成员变量，如果必须定义成员变量，尽量不要修改成员变量的值；不要去根据成员变量的值做一些逻辑判断。
4.http协议
        HTTP：Hyper Text Transfer Protocol超文本传输协议。
        HTTP最大的作用就是确定了请求和响应数据的格式。
        浏览器发送给服务器的数据：请求报文。服务器返回浏览器的数据：响应报文。
            请求：
            请求的三个部分：1.请求行：2.请求消息头；3.请求主体
            请求行包含三个信息：1.请求的方式：2.请求的URL；3.请求的协议（HTTP1.1）
            1>请求消息头：包括客户端告诉服务器的信息：浏览器型号，版本，可以接受的内容类型，我给你发的内容的类型，内容的长度。
            2>请求体，三种情况：
               get方式没有请求体，但是有一个queryString（查询字符串）
               post方式：有请求体，form data
               json格式，有请求体，request payload
            3>响应：
                响应行，响应头，响应体
                1.响应行：响应的协议（http），响应状态吗 3.响应状态（OK）
                2.响应头（respons head）：包含服务器信息：服务器发送给浏览器的信息（内容的媒体类型，编码，内容长度等）
                3.响应体：响应的实际内容（比如请求add.html页面时，响应的内容就是<html><head><body><form>...）


5.会话(servlet-session会话跟踪技术)
    (1)  HTTP无状态：服务器无法判断这两次请求时同一个客户端还是不同的客户端。
         无状态带来的实际问题：第一次请求时添加商品到购物车，第二次请求是结账，如果两次请求服务器无法区分是同一个用户的，那么就会导致混乱
         通过会话跟踪技术解决无状态问题。
    (2)会话跟踪技术：
        客户端第一次发请求给服务器，服务器获取session，获取不到，则创建新的。然后响应给客户端
        第一次客户端给服务器发请求时，会把sessionID带给服务器，那么服务就能获取到了，那么服务器就判断这一次请求和上一次请求是同一个客户端发送的请求。
        常用的API：
        request.getSession() ->获取当前会话，没有则创建一个新的会话。
        request.getSession(true)  ->效果和不带参数相同
        rqueset.getSession(false) ->获取当前会话，没有返回null，不会创建新的会话。

        session.getId()  ->获取sessionID
        session.isNew()  ->判断当前Session是否是新的。(session会话的有效时间是30分钟)
        session.getMaxInactiveInterval()  ->session的非激活时长，默认30分钟or 1800秒
        session.invalidate()
        session.invalidate() -->强制让会话失效。
    (3) session保存会话作用域
        request.getSession();
        session.setAttribute("uname","lina");     // 向当session保存作用域保存一个数据“lina”，对应的key为“uname”
        session.getAttribute("uname");            // 从当前session保存作用域获取指定的key，也就是uname，对应的value值
        --Session.setAttribute(k,v);
          Object session.getAttribute(k);
          void removeAttribute(k);

6.服务器内部转发以及客户端重定向
      1) 服务器内部转发：request.getRequestDisPatcher("...").forward(request,response);
            一次请求响应的过程，对于客户端而言，内部经过多少次转发，客户端是不知道的
            url没有变化
      2) 客户端重定向：  response.sendRedirect("...");
            两次请求响应的过程。客户端知道请求url有变化。
            url有变化。

6.Thymeleaf：（视图模板技术）
    在Index.html页面上加载Java内存中的fruitList的数据，这个过程我们称之为渲染（render）
    thymeleaf是用来帮助我们做视图渲染的一个技术
               

状态码：200：正常响应
    404：找不到资源
    405：请求方式不支持
    500：服务器内部错误。
    302：重定向；