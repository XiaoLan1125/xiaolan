package servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class Servlet07 extends HttpServlet {
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse respoonse) throws ServletException, IOException {
        System.out.println("Servlet07....");
    }
}
