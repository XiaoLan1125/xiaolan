package servlet;

import com.sun.net.httpserver.HttpServer;

import javax.servlet.http.HttpServlet;

public class Servlet extends HttpServlet {
}
