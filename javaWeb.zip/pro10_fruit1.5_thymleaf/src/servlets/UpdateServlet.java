package servlets;

import BAO.FruitDAOImpl;
import myspringmvc.ViewBaseServlet;
import project.DBUtils;
import project.Fruit;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;

/**
 * @program: javaWeb
 * @description:
 * @author: 作者:Xiao lan
 * @create: 2022-07-29 16:32
 **/
@WebServlet("/update.do")
public class UpdateServlet extends ViewBaseServlet {

    FruitDAOImpl fruitDAO = new FruitDAOImpl();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");  //防止中文乱码
        String fname = request.getParameter("fname");
        String priceStr = request.getParameter("fprice");
        int fprice = Integer.parseInt(priceStr);
        String count = request.getParameter("fcount");
        int fcount = Integer.parseInt(count);
        String id = request.getParameter("fid");
        int fid =  Integer.parseInt(id);
        //执行更新数据
        Connection connection = DBUtils.getConnection();
        fruitDAO.upDateFruit(connection, new Fruit(fid,fname,fprice,fcount,null));

        //资源跳转
        //此处需要重定向，目的是重新给IndexServlet发请求，重新获取fruitList然后覆盖session中
        //super.processTemplate("index",request,response);
        response.sendRedirect("index");

    }
}
