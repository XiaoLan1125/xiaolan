package servlets;

import BAO.FruitDAOImpl;
import myspringmvc.ViewBaseServlet;
import project.DBUtils;
import project.Fruit;
import project.FruitDAO;
import util.StringUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;

/**
 * @program: javaWeb
 * @description:
 * @author: 作者:Xiao lan
 * @create: 2022-07-29 13:51
 **/
@WebServlet("/edit.do")
public class EditServlet extends ViewBaseServlet {

    private FruitDAOImpl fruitDAO = new FruitDAOImpl();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String fidStr = request.getParameter("fid");
        if(StringUtil.isNotEmpty(fidStr)){
            int fid = Integer.parseInt(fidStr);
            Connection connection = DBUtils.getConnection();
            Fruit fruit = fruitDAO.getFruitByFid(connection, fid);
            request.setAttribute("fruit",fruit);
            System.out.println(fruit.getFname());
            super.processTemplate("edit",request,response);
        }
    }
}
