package servlets;

import BAO.FruitDAOImpl;
import myspringmvc.ViewBaseServlet;
import project.Fruit;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @program: javaWeb
 * @description:
 * @author: 作者:Xiao lan
 * @create: 2022-07-31 01:51
 **/


@WebServlet("/add.do")
public class AddServlet extends ViewBaseServlet {
    FruitDAOImpl fruitDAO = new FruitDAOImpl();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String fname = request.getParameter("fname");
        String fpriceStr = request.getParameter("fprice");
        int fprice = Integer.parseInt(fpriceStr);
        String fcountStr = request.getParameter("fcount");
        int fcount = Integer.parseInt(fcountStr);
        Fruit fruit = new Fruit(fname,fprice,fcount);
        fruitDAO.addFruit(fruit);
        response.sendRedirect("index");

    }
}
