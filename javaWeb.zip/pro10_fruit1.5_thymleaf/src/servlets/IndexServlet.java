package servlets;

import BAO.FruitDAOImpl;
import myspringmvc.ViewBaseServlet;


import project.DBUtils;
import project.Fruit;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.util.List;

@WebServlet("/index")
public class IndexServlet extends ViewBaseServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        FruitDAOImpl fruitDAO =new FruitDAOImpl();
        Connection connection = DBUtils.getConnection();
        List<Fruit> fruitList = fruitDAO.getFruitList(connection);
        HttpSession session = request.getSession();
        session.setAttribute("fruitList",fruitList);
        //此处的视图名称 index
        //thymleaf会将这个逻辑视图名称对应到物理视图名称上
        super.processTemplate("index",request,response);
    }
}
