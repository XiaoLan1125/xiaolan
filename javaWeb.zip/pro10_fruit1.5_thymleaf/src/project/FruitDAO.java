package project;

import project.DBUtils;
import project.Fruit;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FruitDAO {
    public int addFruit(Fruit fruit){
        Connection connection;
        PreparedStatement preparedStatement= null;
        String sql="insert into fruit(fname,fprice,fcount,remark)VALUE(?,?,?,?)";
        connection = DBUtils.getConnection();
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, fruit.getFname());
            preparedStatement.setInt(2, fruit.getFprice());
            preparedStatement.setInt(3,fruit.getFcount());
            preparedStatement.setString(4, fruit.getRemark());

            int result = preparedStatement.executeUpdate();
            return result;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public List<Fruit> selecrAll(){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Fruit fruit = null;
        List<Fruit> fruitList= new ArrayList<>();
        try {
            connection = DBUtils.getConnection();
            preparedStatement = connection.prepareStatement("select * from fruit;");
            resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                int id = resultSet.getInt("fid");
                String name = resultSet.getString("fname");
                int price = resultSet.getInt("fprice");
                int fcount = resultSet.getInt("fcount");
                String remark = resultSet.getString("remark");
                fruit = new Fruit(id,name,price,fcount,remark);
                fruitList.add(fruit);
            }
            return fruitList;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}
