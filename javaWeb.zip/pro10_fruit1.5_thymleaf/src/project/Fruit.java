package project;

public class Fruit {

    private  int fid;
    private String fname;
    private int fprice;
    private int fcount;
    private String remark;

//    public Fruit(String fname, int fprice, int fcount) {
//        this.fname = fname;
//        this.fprice = fprice;
//        this.fcount = fcount;
//    }

    public Fruit() {
    }

    public Fruit(String fname, int fprice, int fcount) {
        this.fname = fname;
        this.fprice = fprice;
        this.fcount = fcount;
    }

    public Fruit(int id, String fname, int price, int fcount, String remark) {
        this.fid = id;
        this.fname = fname;
        this.fprice = price;
        this.fcount = fcount;
        this.remark = remark;
    }

    public int getFid() {
        return fid;
    }

    public void setFid(int fid) {
        this.fid = fid;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public int getFprice() {
        return fprice;
    }

    public void setFprice(int fprice) {
        this.fprice = fprice;
    }

    public int getFcount() {
        return fcount;
    }

    public void setFcount(int fcount) {
        this.fcount = fcount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "Fruit{" +
                "fid=" + fid +
                ", fname='" + fname + '\'' +
                ", fprice=" + fprice +
                ", fcount=" + fcount +
                ", remark='" + remark + '\'' +
                '}';
    }
}
