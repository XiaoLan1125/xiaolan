package fruit;

import java.sql.*;

public class DBUtils {
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    //获取链接
    public static Connection getConnection(){
        Connection connection =null;
        try {
            connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/fruits?useUnicode=true&characterEncoding=UTF-8&useSSL=false&serverTimezone=GMT%2B8","root","123456");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return connection;
    }

    //释放资源的方法
    public void closeAll(Connection connection, Statement statement, ResultSet resultset){
        try {
            if (resultset != null) {
                resultset.close();
            }
            if(statement!=null){
                statement.close();
            }
            if(connection!=null){
                connection.close();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
