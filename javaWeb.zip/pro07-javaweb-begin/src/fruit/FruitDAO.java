package fruit;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FruitDAO {
    public int addFruit(Fruit fruit){
        Connection connection;
        PreparedStatement preparedStatement= null;
        String sql="insert into fruit(fname,fprice,fcount,remark)VALUE(?,?,?,?)";
        connection = DBUtils.getConnection();
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, fruit.getFname());
            preparedStatement.setString(2, fruit.getPrice());
            preparedStatement.setInt(3,fruit.getFcount());
            preparedStatement.setString(4, fruit.getRemark());

            int result = preparedStatement.executeUpdate();
            return result;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
