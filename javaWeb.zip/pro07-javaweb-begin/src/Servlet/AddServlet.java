package Servlet;

import fruit.Fruit;
import fruit.FruitDAO;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AddServlet extends HttpServlet {    //HttpServlet不在jdk的包中，在servlet-api.jar中，添加tomcat依赖
    //添加tomcat依赖的方法：project Struct-->model-->选中添加

    @Override
    //该方法可以响应html中的post请求
    //request：  客户端给服务端发请求的时，将请求封装成一个request对象发送给服务端
    //response：

    public void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //super.doPost(request, response);

        //防止乱码
        request.setCharacterEncoding("UTF-8");
        String fname = request.getParameter("fname");
        String price = request.getParameter("price");
        String fcountStr = request.getParameter("fcount");
        Integer fcount = Integer.parseInt(fcountStr);
        String remark = request.getParameter("remark");


        System.out.println("fname="+fname);
        System.out.println("price="+price);
        System.out.println("fcount="+fcount);
        System.out.println("remark="+remark);

        FruitDAO fruitDAO= new FruitDAO();
        fruitDAO.addFruit(new Fruit(fname,price,fcount,remark));
        System.out.println("全部运行结束");

    }
}
