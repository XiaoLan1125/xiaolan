package myspringmvc;

import io.Beanfactory;
import io.ClassPathXmlApplicationContext;
import util.StringUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

/**
 * @program: javaWeb
 * @description:
 * &#064;author:  ����:Xiao lan
 * @create: 2022-08-03 21:46
 **/

@WebServlet("*.do")    //����������.do ��β������
public class DispatcherServlet extends ViewBaseServlet {

    private Beanfactory beanfactory;

    public DispatcherServlet(){

    }
    public void init() throws ServletException {
        super.init();
        try {
            beanfactory = new ClassPathXmlApplicationContext();
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        }


    }
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        //����url��http://localhost:8080/pro15/hello.do
        //��ôservletPath��   /hello.
        //˼·��
        //��һ����/hello.do  ->hello
        //�ڶ�����hello  ->HelloController

        //  /hello.do->  hello  ->HelloController
        String servletPath = request.getServletPath();
        servletPath = servletPath.substring(1);
        int lastDotIndex = servletPath.lastIndexOf(".do");
        servletPath = servletPath.substring(0, lastDotIndex);

        Object controllerBeanObj =  beanfactory.getBean(servletPath);

        String operate = request.getParameter("operate");
        if(StringUtil.isEmpty(operate)){
            operate="index";
        }

        try {
            Method[] methods = controllerBeanObj.getClass().getDeclaredMethods();
            for( Method method: methods) {
                if(operate.equals(method.getName())){
                    //1.ͳһ��ȡ�������
                    //��ȡ��ǰ�����Ĳ���������ֵ�����顣
                    Parameter[] parameters = method.getParameters();
                    //parameterValue�������ز�����ֵ
                    Object[] parameterValues = new Object[parameters.length];
                    for(int i=0;i<parameters.length;i++){
                        Parameter parameter = parameters[i];
                        String parameterName = parameter.getName();

                        //�����������request��response��session��
                        if("request".equals(parameterName)){
                            parameterValues[i] = request;
                        } else if ("response".equals(parameterName)) {
                            parameterValues[i] = response;
                        } else if ("session".equals(parameterName)) {
                            parameterValues[i] = request.getSession();
                        }else{
                            //�������л�ȡ����ֵ
                            String parameterValue = request.getParameter(parameterName);
                            String typeName = parameter.getType().getName();
                            Object parameterObj = parameterValue;
                            if(parameterObj!=null){
                                if("java.lang.Integer".equals(typeName)){
                                    parameterObj = Integer.parseInt(parameterValue);
                                }
                            }
                            parameterValues[i]=parameterObj;
                        }
                    }
                    //2.controller����еķ�������
                    method.setAccessible(true);
                    Object returnObj = method.invoke(controllerBeanObj,parameterValues);

                    //3.��ͼ����
                    String methodReturnStr = (String)returnObj;
                    if(methodReturnStr.startsWith("redirect:")) {   //���磺redirect:fruit.do
                        //�����ַ��Ľ�ȡ
                        String redirectStr = methodReturnStr.substring("redirect:".length());
                        //����ض���
                        response.sendRedirect(redirectStr);
                    }else{
                        super.processTemplate(methodReturnStr,request,response);    // ����"edit"
                    }
                }

            }
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}

//java.lang.IllegalArgumentException: argument type mismatch
