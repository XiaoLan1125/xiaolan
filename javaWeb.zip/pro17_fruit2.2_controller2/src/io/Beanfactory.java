﻿package io;

public interface Beanfactory {
    Object getBean(String id);
}
