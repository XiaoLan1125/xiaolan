﻿package io;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * @program: javaWeb
 * @description:
 * @author: 作者:Xiao lan
 * @create: 2022-10-10 20:12
 **/
public class ClassPathXmlApplicationContext implements Beanfactory{
    private Map<String,Object> beanMap = new HashMap<>();

    public ClassPathXmlApplicationContext() throws NoSuchFieldException {
        try {

            InputStream inputStream = getClass().getClassLoader().getResourceAsStream("applicationContext.xml");
            //创建DocumentBuliderFactory
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            //创建DocumentBuilder对象
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            //创建Document对象
            Document document = documentBuilder.parse(inputStream);

            //获取所有的bean节点
            NodeList beanNodeList = document.getElementsByTagName("bean");
            for( int i = 0;i<beanNodeList.getLength(); i++ ){
                Node beanNode = beanNodeList.item(i);
                if(beanNode.getNodeType() == Node.ELEMENT_NODE){
                    Element beanElement = (Element) beanNode;
                    String beanId= beanElement.getAttribute("id");
                    String className = beanElement.getAttribute("class");
                    Class BeanClass = Class.forName(className);
                    //创建bean实例
                    Object beanObj = BeanClass.newInstance();

                    //组装bean之间的依赖关系


//                    servletControllerField.setAccessible(true);
//                    servletControllerField.set(beanObj,this.getServletContext());

                    beanMap.put(beanId,beanObj);

                }
            }
            for(int i = 0;i<beanNodeList.getLength();i++){
                Node beanNode = beanNodeList.item(i);
                if(beanNode.getNodeType() == Node.ELEMENT_NODE){
                    Element beanElement = (Element) beanNode;
                    String benaId = beanElement.getAttribute("id");
                    NodeList childNodelist = beanElement.getChildNodes();
                    for(int j = 0;j<childNodelist.getLength();j++){
                        Node beanChildNode= beanNodeList.item(j);
                        if(beanChildNode.getNodeType()==Node.ELEMENT_NODE && "property".equals(beanChildNode.getNodeName())){
                            Element propertyElement = (Element) beanChildNode;
                            String propertyName = propertyElement.getAttribute("name");
                            String refName =propertyElement.getAttribute("ref");
                            //找到porpertyRef对应的实例
                            Object refObj = beanMap.get(refName);
                            //将refObj设置到当前bean对应的property属性上去。
                            Object beanObj = beanMap.get(benaId);
                            //反射技术
                            Class beanClass = beanObj.getClass();
                            Field propertyField = beanClass.getDeclaredField(propertyName);
                            propertyField.setAccessible(true);
                            propertyField.set(beanObj,refObj);

                        }
                    }
                }
            }
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }



    @Override
    public Object getBean(String id) {
        return beanMap.get(id);
    }
}
