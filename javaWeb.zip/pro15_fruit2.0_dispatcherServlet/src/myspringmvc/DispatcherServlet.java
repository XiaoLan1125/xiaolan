package myspringmvc;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import util.StringUtil;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * @program: javaWeb
 * @description:
 * &#064;author:  ����:Xiao lan
 * @create: 2022-08-03 21:46
 **/

@WebServlet("*.do")    //����������.do ��β������
public class DispatcherServlet extends HttpServlet {

    private Map<String,Object> beanMap = new HashMap<>();
    public DispatcherServlet(){

    }
    public void init(){
        System.out.println("config init");
        try {

            InputStream inputStream = getClass().getClassLoader().getResourceAsStream("applicationContext.xml");
            //����DocumentBuliderFactory
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            //����DocumentBuilder����
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            //����Document����
            Document document = documentBuilder.parse(inputStream);

            //��ȡ���е�bean�ڵ�
            NodeList beanNodeList = document.getElementsByTagName("bean");
            for( int i = 0;i<beanNodeList.getLength(); i++ ){
                Node beanNode = beanNodeList.item(i);
                if(beanNode.getNodeType() == Node.ELEMENT_NODE){
                    Element beanElement = (Element) beanNode;
                    String beanId= beanElement.getAttribute("id");
                    String className = beanElement.getAttribute("class");
                    Class controllerBeanClass = Class.forName(className);
                    Object beanObj = controllerBeanClass.newInstance();
                    Method serServletContextMethod = controllerBeanClass.getDeclaredMethod("setServletContext", ServletContext.class);
                    serServletContextMethod.invoke(beanObj,this.getServletContext());
                    Field servletControllerField = controllerBeanClass.getDeclaredField("servletContext");
//                    servletControllerField.setAccessible(true);
//                    servletControllerField.set(beanObj,this.getServletContext());

                    beanMap.put(beanId,beanObj);

                }
            }
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException | NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }

    }
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        //����url��http://localhost:8080/pro15/hello.do
        //��ôservletPath��   /hello.
        //˼·��
        //��һ����/hello.do  ->hello
        //�ڶ�����hello  ->HelloController

        //  /hello.do->  hello  ->HelloController
        String servletPath = request.getServletPath();
        servletPath = servletPath.substring(1);
        int lastDotIndex = servletPath.lastIndexOf(".do");
        servletPath = servletPath.substring(0, lastDotIndex);

        Object controllerBeanObj =  beanMap.get(servletPath);

        String operate = request.getParameter("operate");
        if(StringUtil.isEmpty(operate)){
            operate="index";
        }

        try {
            Method method = controllerBeanObj.getClass().getDeclaredMethod(operate, HttpServletRequest.class, HttpServletResponse.class);
            if(method!=null){
                method.setAccessible(true);
                method.invoke(controllerBeanObj,request,response);
            }else {
                throw new RuntimeException("operateֵ�Ƿ���");
            }
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}
