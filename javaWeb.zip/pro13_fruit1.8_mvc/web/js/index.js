﻿function delFruit(fid){
    if(confirm('是否确认删除？')){
            window.location.href ='fruit.do?fid='+fid+'&operate=delete';
        }
}
function page(pageno){
    if(confirm("是否跳转")){
        if(pageno>0){
            window.location.href="fruit.do?pagenumber="+pageno;
        }
    }

}