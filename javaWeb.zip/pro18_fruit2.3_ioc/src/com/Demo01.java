package com;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

/**
 * @program: javaWeb
 * @description:
 * @author: 作者:Xiao lan
 * @create: 2022-10-10 19:29
 **/

public class Demo01 extends HttpServlet {
    @Override
    public void init() throws ServletException {
        ServletConfig servletConfig = getServletConfig();
        String intString = servletConfig.getInitParameter("hello");
        System.out.println("initStrinf="+intString);

        ServletContext servletContext = getServletContext();
        String applocationString = servletContext.getInitParameter("contextConfigLocation");
        System.out.println("contextConfigLocation"+applocationString);
    }
}
