package servlets;

import BAO.FruitDAOImpl;
import myspringmvc.ViewBaseServlet;
import project.DBUtils;
import project.Fruit;
import util.StringUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.List;

/**
 * @program: javaWeb
 * @description:
 * @author: ����:Xiao lan
 * @create: 2022-08-02 21:58
 **/
@WebServlet("/fruit.do")
public class FruitServlet extends ViewBaseServlet {
    FruitDAOImpl fruitDAO = new FruitDAOImpl();
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       request.setCharacterEncoding("utf-8");
        String operate = request.getParameter("operate");
        if(StringUtil.isEmpty(operate)){
            operate="index";
        }

        //��ȡ��ǰ������з���
        Method[] methods = this.getClass().getDeclaredMethods();
        for( Method m:methods ) {
            String methodName = m.getName();
            if(operate.equals(methodName)){
                //�ҵ���operateͬ���ķ�������ͬ�����似������
                try {
                    m.invoke(this,request,response);
                    return ;
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                } catch (InvocationTargetException e) {
                    throw new RuntimeException(e);
                }
            }

        }
        throw new RuntimeException("operateֵ�Ƿ���");

//        switch(operate){
//            case "index":
//                index(request,response);
//                break;
//            case "add":
//                add(request,response);
//                break;
//            case"delete":
//                delete(request,response);
//                break;
//            case"edit":
//                edit(request,response);
//                break;
//            case"update":
//                update(request,response);
//                break;
//            default:
//                throw new RuntimeException("operateֵ�Ƿ���");
//        }
    }
    private void index(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String oper = request.getParameter("oper");
        //���oper!=null, ˵����ͨ�������Ĳ�ѯ��ť�õ���
        //���oper = null, ˵��û�е��ѯ���б���Ĭ����ʾ�������б��ǲ�ѯ���õ����б�
        HttpSession session = request.getSession();

        //���õ�ǰҳĬ��Ϊ1
        int pagenumber=1;
        String keyword = null;
        if(StringUtil.isNotEmpty(oper) && "search".equals(oper)){
            //˵���ǵ��������ѯ���͹���������
            //��ʱ��pagenoӦ�û�ԭΪ1��keyword Ӧ�ô���������ֻ�ȡ
            pagenumber = 1;
            keyword = request.getParameter("keyword");

            //���keywordΪnull����Ҫ����Ϊ���ַ���������ִ�в�ѯ��ʱ�����null

            if(StringUtil.isEmpty(keyword)){
                keyword = "";
            }
            //��keyword���浽session��
            session.setAttribute("keyword",keyword);

        }else{
            //˵���˴����ǵ�������Ĳ�ѯ��ť�õ���keyword
            String pageNoStr = request.getParameter("pagenumber");
            if(StringUtil.isNotEmpty(pageNoStr)){
                pagenumber=Integer.parseInt(pageNoStr);
            }

            //
            Object keywordObj = session.getAttribute("keyword");
            if(keywordObj!=null){
                keyword = (String) keywordObj;
            }else{
                keyword="";
            }
        }
        session.setAttribute("pageno",pagenumber);

        int  countfruit = fruitDAO.countFruit(keyword);
        int  countpage = (countfruit+5-1)/5;
        session.setAttribute("countpage",countpage);

        List<Fruit> fruitList = fruitDAO.getFruitList(keyword,pagenumber);
        session.setAttribute("fruitList",fruitList);
        //�˴�����ͼ���� index
        //thymleaf�Ὣ����߼���ͼ���ƶ�Ӧ��������ͼ������
        super.processTemplate("index",request,response);
    }
    private void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String fname = request.getParameter("fname");
        String fpriceStr = request.getParameter("fprice");
        int fprice = Integer.parseInt(fpriceStr);
        String fcountStr = request.getParameter("fcount");
        int fcount = Integer.parseInt(fcountStr);
        Fruit fruit = new Fruit(fname,fprice,fcount);
        fruitDAO.addFruit(fruit);
        response.sendRedirect("fruit.do");

    }
    private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fidStr = request.getParameter("fid");
        if(StringUtil.isNotEmpty(fidStr)){
            int fid = Integer.parseInt(fidStr);
            fruitDAO.delFruit(fid);

            response.sendRedirect("fruit.do");
        }
    }
    private void edit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String fidStr = request.getParameter("fid");
        if(StringUtil.isNotEmpty(fidStr)){
            int fid = Integer.parseInt(fidStr);
            Connection connection = DBUtils.getConnection();
            Fruit fruit = fruitDAO.getFruitByFid(connection, fid);
            request.setAttribute("fruit",fruit);
            super.processTemplate("edit",request,response);
        }
    }
    private void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("update style");
        request.setCharacterEncoding("utf-8");  //��ֹ��������
        String fname = request.getParameter("fname");
        String priceStr = request.getParameter("fprice");
        int fprice = Integer.parseInt(priceStr);
        String count = request.getParameter("fcount");
        int fcount = Integer.parseInt(count);
        String id = request.getParameter("fid");
        int fid =  Integer.parseInt(id);
        //ִ�и�������
        Connection connection = DBUtils.getConnection();
        fruitDAO.upDateFruit(connection, new Fruit(fid,fname,fprice,fcount,null));

        //��Դ��ת
        //�˴���Ҫ�ض���Ŀ�������¸�IndexServlet���������»�ȡfruitListȻ�󸲸�session��
        //super.processTemplate("index",request,response);
        response.sendRedirect("fruit.do");

    }


}
