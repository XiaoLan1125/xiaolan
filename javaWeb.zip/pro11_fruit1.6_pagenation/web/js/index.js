﻿function delFruit(fid){
    if(confirm('是否确认删除？')){
            window.location.href ="del.do?fid="+fid;
        }
}
function page(pageno){
    if(confirm("是否跳转")){
        if(pageno>0){
            window.location.href="index?pagenumber="+pageno;
        }
    }

}