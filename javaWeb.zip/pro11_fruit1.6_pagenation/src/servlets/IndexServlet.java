package servlets;


import BAO.FruitDAOImpl;
import jdk.jshell.execution.Util;
import myspringmvc.ViewBaseServlet;


import project.DBUtils;
import project.Fruit;
import util.StringUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.util.List;

@WebServlet("/index")
public class IndexServlet extends ViewBaseServlet {

    FruitDAOImpl fruitDAO =new FruitDAOImpl();
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int pagenumber=1;
        String pageNoStr = request.getParameter("pagenumber");
        if(StringUtil.isNotEmpty(pageNoStr)){
            pagenumber=Integer.parseInt(pageNoStr);
        }

        HttpSession session = request.getSession();
        session.setAttribute("pageno",pagenumber);

        int  countfruit = fruitDAO.countFruit();
        int  countpage = (countfruit+5-1)/5;
        session.setAttribute("countpage",countpage);

        List<Fruit> fruitList = fruitDAO.getFruitList(pagenumber);
        session.setAttribute("fruitList",fruitList);
        //此处的视图名称 index
        //thymleaf会将这个逻辑视图名称对应到物理视图名称上
        super.processTemplate("index",request,response);
    }
}
